const iglesiaccvpar = () =>{

    return(
        <div>
            
        </div>
    );
};

export default iglesiaccvpar;